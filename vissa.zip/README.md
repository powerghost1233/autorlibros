# Catálogo de libros — David Milán

Estructura lista para desplegar en Netlify. Archivos clave:
- `index.html`
- Portadas en `assets/portadas/`

## Despliegue rápido
1. Sube esta carpeta a un repo o arrástrala a Netlify (Drag & Drop).
2. Configuración de build: **no necesaria** (sitio estático).
3. Asegúrate de que las rutas de imágenes sean `/assets/portadas/...` (ya configurado).

## Editar contenido
- Añade/quita libros duplicando un `<article class="card col-4">` y su modal correspondiente.
- Cambia enlaces de Amazon en los `<a class="btn" ...>`.

¡Listo! 🎉
